const express = require("express");
const multer = require("multer");
const Minio = require("minio");
require("dotenv").config({ path: __dirname + "/../.env" });

const router = express.Router();

// ✅ MinIO Configuration
const minioClient = new Minio.Client({
  endPoint: process.env.MINIO_ENDPOINT,
  port: parseInt(process.env.MINIO_PORT),
  useSSL: false,
  accessKey: process.env.MINIO_ACCESS_KEY,
  secretKey: process.env.MINIO_SECRET_KEY,
});

const BUCKET_NAME = process.env.MINIO_BUCKET || "nextdrive";

// ✅ Configure Multer (Temporary Memory Storage)
const storage = multer.memoryStorage();
const upload = multer({ storage });

// ✅ Upload File API
router.post("/upload", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const fileName = `${Date.now()}_${req.file.originalname}`;

    await minioClient.putObject(BUCKET_NAME, fileName, req.file.buffer, req.file.size);

    const fileURL = `http://${process.env.MINIO_ENDPOINT}:${process.env.MINIO_PORT}/${BUCKET_NAME}/${fileName}`;
    
    return res.json({ message: "✅ File uploaded successfully", url: fileURL });
  } catch (error) {
    console.error("❌ Upload error:", error);
    return res.status(500).json({ error: "Upload failed" });
  }
});

// ✅ Get Uploaded Files List
router.get("/", async (req, res) => {
  try {
    const objects = [];
    const stream = minioClient.listObjects(BUCKET_NAME, "", true);

    stream.on("data", (obj) => objects.push(obj.name));
    stream.on("end", () => res.json(objects));
    stream.on("error", (error) => {
      console.error("❌ List error:", error);
      res.status(500).json({ error: "Failed to fetch files" });
    });
  } catch (error) {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;

