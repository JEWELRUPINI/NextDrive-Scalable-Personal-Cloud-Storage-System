const Minio = require("minio");
require("dotenv").config({ path: __dirname + "/.env" }); // Ensure .env is loaded

// Debugging: Check if .env values are loaded
console.log("✅ MINIO DEBUG");
console.log("✅ MINIO_ENDPOINT:", process.env.MINIO_ENDPOINT);
console.log("✅ MINIO_PORT:", process.env.MINIO_PORT);
console.log("✅ MINIO_ACCESS_KEY:", process.env.MINIO_ACCESS_KEY);
console.log("✅ MINIO_SECRET_KEY:", process.env.MINIO_SECRET_KEY);

const minioClient = new Minio.Client({
  endPoint: process.env.MINIO_ENDPOINT,
  port: parseInt(process.env.MINIO_PORT, 10),
  useSSL: false,
  accessKey: process.env.MINIO_ACCESS_KEY,
  secretKey: process.env.MINIO_SECRET_KEY,
});

const BUCKET_NAME = process.env.MINIO_BUCKET;

// Upload File
const uploadFile = async (file) => {
  const filePath = `${Date.now()}-${file.originalname}`;
  await minioClient.fPutObject(BUCKET_NAME, filePath, file.path);
  return `http://${process.env.MINIO_ENDPOINT}:${process.env.MINIO_PORT}/${BUCKET_NAME}/${filePath}`;
};

// List Files
const listFiles = async () => {
  const dataStream = minioClient.listObjects(BUCKET_NAME, "", true);
  return new Promise((resolve, reject) => {
    const files = [];
    dataStream.on("data", (obj) => files.push(obj.name));
    dataStream.on("end", () => resolve(files));
    dataStream.on("error", (err) => reject(err));
  });
};

module.exports = { uploadFile, listFiles };
